from tkinter import *
import tkinter.ttk as widget
import tkinter.simpledialog as dlg
import tkinter.messagebox as MsgBox
import os

# Initialize Window (Updated 8/2/2021)
root = Tk()
root.title('Shell 2021')

# Command Functions (Updated 8/2/2021)
def explore():
    for x in range(1,49):
        os.startfile('explorer.exe')

def zerobyzero():
    os.startfile('0 ÷ 0 Explained.mp4')

def yt_to_mp4():
    iWant = dlg.askstring(None, "Enter URL: ")
    os.system(f'ytdl.exe "{iWant}"')
    MsgBox.showinfo(None, f"Video Saved At {os.getcwd()}")
    
# Command Windows (Updated 8/2/2021)
widget.Label(root, text="Commands:").grid(row=0, column=0, columnspan=3)

widget.Button(root, text="Youtube Downloader", command=yt_to_mp4).grid(row=1, column=0)
widget.Button(root, text="0 divided by 0 Explained", command=zerobyzero).grid(row=1, column=1)
widget.Button(root, text="Windows Explorer", command=explore).grid(row=1, column=2)

# Mainloop and Event Bindings (Updated 8/2/2021)
root.mainloop()
